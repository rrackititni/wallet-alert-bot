# Copy-trade agent

Mirrors the buys/sells of the wallets in `agent-config.json` (dvces, Decu, trunoest, cupsey).
**Everything starts in paper mode.** No real trade happens until you flip three separate switches.

## How it works
1. Helius webhook -> `server.js` -> `agent.handleWebhookTx` (runs alongside the alert bot, not behind it).
2. `classify.js` reads the wallet's net balance changes: BUY / SELL, token, size (SOL or USDC/USDT base).
3. Cheap filters first: stale signal, min buy size, add-on buys, then a real Jupiter quote for OUR size
   (price impact), then RugCheck (score + "did this wallet create the token").
4. Survivors are **always** paper-filled at the quoted price, recording slippage vs the trader and detection lag.
5. If the wallet is `"live"` and the live switches are on, the same signal executes for real behind the risk limits.
6. When they sell X% of a position, we sell X% of ours. Small trims are batched (`minSellFraction`, default 10%)
   so we don't pay a swap fee per 2% trim; a sell of 90%+ is a full exit and always goes through immediately.
7. Events for the same wallet + token are processed strictly in order, so a fast buy-then-sell can't leave us
   holding a token the trader already dumped.

## Turning it on (paper)
Railway -> Variables:
- `HELIUS_WEBHOOK_SECRET` (long random) - and paste the SAME value as the **Auth Header** on the Helius webhook
- `ADMIN_TOKEN` (different long random)
- `AGENT_ENABLED=true`
- `DATA_DIR=/data`, plus a **Volume mounted at /data** (otherwise the ledger is wiped every deploy)

Helius -> edit the existing webhook -> add the 4 addresses from `agent-config.json` to Account Addresses (SWAP type).

On boot you should see an "Agent online" message in Discord that includes a Jupiter self-test.
If it says FAILED, set `JUP_BASE` (see env.example).

## Reading the results
Open `https://YOUR-APP.up.railway.app/agent/admin` on your phone, enter the admin token, tap **Post summary to Discord**
(it also posts itself daily at 00:00 UTC): per wallet - paper PnL, average fill vs the trader, detection lag,
and the top reasons trades were skipped.
The number that matters is **fill vs trader**: if it's consistently large, the edge is gone by the time we can copy.
Also watch whether Decu and trunoest keep buying the same tokens within seconds of each other - if so, they are one signal.

## Going live (only after paper results justify it)
1. `agent-config.json`: set that wallet's `"mode": "live"` (start with dvces only).
2. Railway: `AGENT_LIVE=true` and `TRADING_ENABLED=true`, then redeploy.
Live money fails closed: unknown RugCheck result = skip. Hard limits: `AGENT_BUDGET_SOL`, `AGENT_MAX_POSITIONS`,
`AGENT_DAILY_LOSS_SOL`, `AGENT_SOL_RESERVE`.

**Shared wallet:** the alert bot's `MAX_DAILY_SOL` and the agent's `AGENT_BUDGET_SOL` are separate budgets on the same
wallet. Keep their sum within what the wallet holds.

## Admin page (bookmark `/agent/admin` on your phone)
Type the token (a password manager can fill it), then tap: **Status**, **Post summary**, **Pause new live buys**,
**Resume**, or **PANIC** (tick the confirm box first: pauses and sells every live position; exits keep running while paused).
The token travels in the request body only. It is deliberately NOT accepted in the URL, because URLs land in
server logs and browser history, and nothing that changes state is a GET, so a link preview can't trigger it.
`ADMIN_TOKEN` must be at least 24 random characters or the agent refuses to start.
For scripts: send the header `x-admin-token`, `GET /agent/status`, `POST /agent/pause|resume|summary|panic`.

## Known limits
- Tokens still on the pump.fun bonding curve may have no Jupiter route; those show up as `no-route` skips.
- Live PnL is approximate (fees/rent are estimated); the wallet balance is the source of truth.
- Skipped trades are counted, not simulated, so the summary shows what filters removed but not what they'd have earned.
- Live buys fail closed: if RugCheck has no data on a token yet (common for brand-new launches) the live buy is skipped
  (`live-unknown-risk`). Paper still records it. Expect live to trade fewer coins than paper.
- Own-token detection relies on RugCheck's creator field, so it can't see a token RugCheck hasn't indexed yet.
- Paper history keeps the most recent 3,000 exits, so long-run realized totals in the summary eventually cover only that window.
