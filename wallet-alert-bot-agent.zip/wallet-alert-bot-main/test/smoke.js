"use strict";
// End-to-end smoke test: boots the real server with local stand-ins for Discord and Jupiter,
// sends it a fake Helius webhook, and checks auth, paper fills, admin routes, and persistence.
//   node test/smoke.js
const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");
const assert = require("assert");

const SOL = "So11111111111111111111111111111111111111112";
const USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
const WALLET = "BCagckXeMChUKrHEd6fKFA1uiWDtcmCXMsqaheLiUPJd"; // dvces (from agent-config.json)
const MINT = "MintAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
const TOKEN = "t".repeat(32) + "-admin";
const SECRET = "s".repeat(32);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const discordPosts = [];
const discord = http.createServer((req, res) => {
  let b = "";
  req.on("data", (c) => (b += c));
  req.on("end", () => {
    try { discordPosts.push(JSON.parse(b)); } catch {}
    res.writeHead(204).end();
  });
});
const jupiter = http.createServer((req, res) => {
  const u = new URL(req.url, "http://x");
  res.setHeader("content-type", "application/json");
  if (u.pathname === "/quote") {
    const out = u.searchParams.get("outputMint");
    const amount = BigInt(u.searchParams.get("amount"));
    const outAmount = out === USDC ? "100000000" : String(amount * 20n);
    return res.end(JSON.stringify({ outAmount, priceImpactPct: "0.001" }));
  }
  res.statusCode = 404;
  res.end("{}");
});

async function main() {
  await new Promise((r) => discord.listen(4101, r));
  await new Promise((r) => jupiter.listen(4102, r));
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "agent-smoke-"));
  const server = spawn("node", ["server.js"], {
    cwd: path.join(__dirname, ".."),
    env: {
      ...process.env,
      PORT: "4100",
      DISCORD_WEBHOOK_URL: "http://127.0.0.1:4101/hook",
      HELIUS_WEBHOOK_SECRET: SECRET,
      ADMIN_TOKEN: TOKEN,
      AGENT_ENABLED: "true",
      JUP_BASE: "http://127.0.0.1:4102",
      DATA_DIR: dataDir,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let log = "";
  server.stdout.on("data", (d) => (log += d));
  server.stderr.on("data", (d) => (log += d));

  const base = "http://127.0.0.1:4100";
  try {
    for (let i = 0; i < 40; i++) {
      try { if ((await fetch(base + "/health")).ok) break; } catch {}
      await sleep(250);
    }
    const buy = {
      signature: "smokeSig1", timestamp: Math.floor(Date.now() / 1000), type: "SWAP", feePayer: WALLET,
      accountData: [{ account: WALLET, nativeBalanceChange: -1_500_000_000 }],
      tokenTransfers: [{ fromUserAccount: "Pool", toUserAccount: WALLET, mint: MINT, tokenAmount: 1000 }],
    };

    // 1. webhook auth is enforced
    let r = await fetch(base + "/helius-webhook", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify([buy]) });
    assert.equal(r.status, 401, "webhook without secret must be rejected");

    // 2. a valid webhook produces a paper position
    r = await fetch(base + "/helius-webhook", { method: "POST", headers: { "content-type": "application/json", authorization: SECRET }, body: JSON.stringify([buy]) });
    assert.equal(r.status, 200);
    await sleep(3500);

    const hdr = { "x-admin-token": TOKEN };
    r = await fetch(base + "/agent/status", { headers: hdr });
    assert.equal(r.status, 200);
    const st = await r.json();
    assert.equal(st.paperOpen, 1, "one paper position expected; got " + JSON.stringify(st.stats));
    assert.equal(st.liveArmed, false, "live must be disarmed by default");

    // 3. admin auth rules
    assert.equal((await fetch(`${base}/agent/status?token=${TOKEN}`)).status, 401, "query-string token must be rejected");
    assert.equal((await fetch(base + "/agent/status")).status, 401);
    assert.equal((await fetch(base + "/agent/pause")).status, 404, "state-changing routes must not exist as GET");
    assert.equal((await fetch(base + "/agent/pause", { method: "POST", headers: hdr })).status, 200);
    assert.equal((await (await fetch(base + "/agent/status", { headers: hdr })).json()).paused, true);
    assert.equal((await fetch(base + "/reload-wallets", { method: "POST" })).status, 401, "reload-wallets must need the token");

    // 4. phone admin page
    r = await fetch(base + "/agent/admin");
    assert.equal(r.status, 200);
    assert.match(await r.text(), /PANIC/);
    r = await fetch(base + "/agent/admin", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: `token=${TOKEN}&action=resume` });
    assert.equal(r.status, 200);
    r = await fetch(base + "/agent/admin", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "token=nope&action=status" });
    assert.equal(r.status, 401);
    r = await fetch(base + "/agent/panic", { method: "POST", headers: hdr, body: "{}" });
    assert.match(JSON.stringify(await r.json()), /confirm/, "panic without confirm must refuse");

    // 5. startup report reached Discord and Jupiter self-check passed
    const online = discordPosts.find((p) => p.embeds && p.embeds[0].title.includes("Agent online"));
    assert.ok(online, "startup report posted");
    assert.match(JSON.stringify(online), /OK \(SOL/);

    // 6. state persisted to DATA_DIR on shutdown
    server.kill("SIGTERM");
    await sleep(800);
    const saved = JSON.parse(fs.readFileSync(path.join(dataDir, "agent-state.json"), "utf8"));
    assert.equal(Object.keys(saved.paper.positions).length, 1, "ledger must survive shutdown");

    console.log("SMOKE TEST PASSED");
  } catch (e) {
    console.error("SMOKE TEST FAILED:", e.message, "\n--- server log ---\n" + log.slice(-1500));
    process.exitCode = 1;
  } finally {
    server.kill();
    discord.close();
    jupiter.close();
  }
}
main();
