"use strict";
const test = require("node:test");
const assert = require("node:assert");
const { classify } = require("../agent/classify");
const { createAgent } = require("../agent");
const { createState } = require("../agent/state");
const { loadAgentConfig } = require("../agent/config");

const SOL = "So11111111111111111111111111111111111111112";
const USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
const W = "BCagckXeMChUKrHEd6fKFA1uiWDtcmCXMsqaheLiUPJd";
const MINT = "MintAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
const MINT2 = "MintBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB";
const POOL = "PoolPoolPoolPoolPoolPoolPoolPoolPoolPoolPool1";

const tt = (from, to, mint, amt) => ({ fromUserAccount: from, toUserAccount: to, mint, tokenAmount: amt });
const nat = (lamports) => [{ account: W, nativeBalanceChange: lamports }];
const tx = (o) => ({ signature: "sig" + Math.random(), timestamp: Math.floor(Date.now() / 1000), type: "SWAP", ...o });

// ---------------- classify ----------------
test("SOL buy is a BUY with SOL base", () => {
  const r = classify(tx({ accountData: nat(-1_005_000_000), tokenTransfers: [tt(POOL, W, MINT, 5000)] }), W);
  assert.equal(r.signal.side, "BUY");
  assert.equal(r.signal.base.kind, "SOL");
  assert.ok(Math.abs(r.signal.base.amount - 1.005) < 1e-9);
});

test("USDC buy is a BUY (old heuristic read this as a SELL)", () => {
  const r = classify(tx({ tokenTransfers: [tt(W, POOL, USDC, 250), tt(POOL, W, MINT, 900)] }), W);
  assert.equal(r.signal.side, "BUY");
  assert.equal(r.signal.base.kind, "STABLE");
  assert.equal(r.signal.base.amount, 250);
});

test("SOL sell is a SELL", () => {
  const r = classify(tx({ accountData: nat(2_000_000_000), tokenTransfers: [tt(W, POOL, MINT, 400)] }), W);
  assert.equal(r.signal.side, "SELL");
  assert.equal(r.signal.mint, MINT);
});

test("multi-hop: intermediate token nets to zero and is ignored", () => {
  const r = classify(tx({
    accountData: nat(-500_000_000),
    tokenTransfers: [tt(W, POOL, MINT2, 10), tt(POOL, W, MINT2, 10), tt(POOL, W, MINT, 77)],
  }), W);
  assert.equal(r.signal.side, "BUY");
  assert.equal(r.signal.mint, MINT);
});

test("token->token swap is skipped (two non-base legs)", () => {
  const r = classify(tx({ tokenTransfers: [tt(W, POOL, MINT2, 10), tt(POOL, W, MINT, 77)] }), W);
  assert.equal(r.skip, "multi-token");
});

test("free token transfer in (airdrop) is NOT a buy", () => {
  const r = classify(tx({ type: "TRANSFER", tokenTransfers: [tt(POOL, W, MINT, 1000)] }), W);
  assert.equal(r.skip, "no-base-leg");
});

test("plain transfer out (moving tokens) is NOT a sell", () => {
  const r = classify(tx({ type: "TRANSFER", tokenTransfers: [tt(W, POOL, MINT, 1000)] }), W);
  assert.equal(r.skip, "no-base-leg");
});

test("dust sale under the noise floor still counts as a SELL when it's a swap", () => {
  const r = classify(tx({ accountData: nat(-5000), tokenTransfers: [tt(W, POOL, MINT, 1)] }), W);
  assert.equal(r.signal.side, "SELL");
});

// ---------------- agent harness ----------------
function harness(overrides = {}) {
  const posts = [];
  const calls = { swaps: 0, quotes: [] };
  let solBalance = overrides.solBalance ?? 0.4;
  const held = new Map(); // mint -> BigInt (our wallet)
  let their = overrides.theirBalances ?? { preRaw: 1000n, postRaw: 500n, solDeltaLamports: null, feeLamports: 5000 };
  const chain = {
    owner: "OurWallet",
    canTrade: true,
    getSolUsd: async () => 100,
    getDecimals: async () => 6,
    quote: async (inp, out, amount) => {
      calls.quotes.push({ inp, out, amount: String(amount) });
      if (overrides.noRoute) { const e = new Error("no route"); e.noRoute = true; throw e; }
      // buy: 1 SOL -> 1,000,000 tokens (6dp => 1.0 token per 1 SOL... use simple ratio)
      if (inp === SOL) return { outAmount: String(BigInt(amount) * 20n), priceImpactPct: String(overrides.impact ?? 0.01) };
      return { outAmount: String((BigInt(amount) * (overrides.exitMult ?? 1n)) / 20n), priceImpactPct: "0.01" };
    },
    swap: async (q) => { calls.swaps++; if (overrides.swapFails) throw new Error("boom"); return "SIG" + calls.swaps; },
    getSolBalance: async () => solBalance,
    getTokenBalanceRaw: async (mint) => held.get(mint) ?? 0n,
    getTokenBalanceUi: async () => 0,
    getTxBalances: async (sig, who, mint) => {
      if (who === "OurWallet") return { preRaw: 0n, postRaw: 20_000_000n, solDeltaLamports: -50_000_000, feeLamports: 5000 };
      return their;
    },
  };
  chain.swap = async (q) => {
    calls.swaps++;
    if (overrides.swapFails) throw new Error("boom");
    held.set(MINT, 20_000_000n);
    return "SIG" + calls.swaps;
  };
  const cfg = { wallets: [{
    address: W, label: "dvces", mode: overrides.mode ?? "paper", sizeSol: 0.05, minBuyUsd: 100,
    maxPriceImpactPct: 3, maxRugScore: 60, skipOwnTokens: true, mirrorAddOns: false, mirrorSells: true,
    maxLagSec: 30, slippageBps: 500, minSellFraction: 0.1,
  }] };
  const env = {
    agentLive: overrides.agentLive ?? false, tradingEnabled: overrides.tradingEnabled ?? true,
    budgetSol: 0.27, maxPositions: 3, dailyLossSol: 0.09, solReserve: 0.03, slippageBps: 500, paperFeeSol: 0.0003,
  };
  const state = createState({ dir: null, log: { error() {} } });
  const rugcheck = async () => {
    if (overrides.rugDelayMs) await new Promise((r) => setTimeout(r, overrides.rugDelayMs));
    return overrides.rc ?? { score: 10, creator: "SomeoneElse", topRisks: [] };
  };
  const post = async (p) => { posts.push(p); };
  const agent = createAgent({ cfg, env, chain, rugcheck, post, state, log: { error() {} } });
  return { agent, state, posts, calls, held, setBalance: (v) => (solBalance = v), setTheirBalances: (v) => (their = v) };
}

// $150 buy at SOL=$100 => 1.5 SOL
const buyTx = (sol = 1.5, mint = MINT) => tx({ accountData: nat(-Math.round(sol * 1e9)), tokenTransfers: [tt(POOL, W, mint, 1000)] });
const sellTx = (mint = MINT) => tx({ accountData: nat(700_000_000), tokenTransfers: [tt(W, POOL, mint, 500)] });

test("paper: buy below min size is skipped and counted", async () => {
  const h = harness();
  await h.agent.handleWebhookTx(buyTx(0.5)); // $50
  assert.equal(Object.keys(h.state.data.paper.positions).length, 0);
  assert.equal(h.state.data.stats.dvces.skipped["below-min-size"], 1);
});

test("paper: qualifying buy opens a position with slippage-vs-trader recorded", async () => {
  const h = harness();
  await h.agent.handleWebhookTx(buyTx());
  const p = h.state.data.paper.positions[`dvces:${MINT}`];
  assert.ok(p, "paper position opened");
  assert.equal(p.costSol, 0.05);
  assert.equal(typeof p.slipVsThemPct, "number");
  assert.equal(h.calls.swaps, 0, "paper mode never swaps");
});

test("paper: their partial sell mirrors the same fraction, then a >=90% exit closes it", async () => {
  const h = harness();
  await h.agent.handleWebhookTx(buyTx());
  const before = BigInt(h.state.data.paper.positions[`dvces:${MINT}`].rawHeld);
  await h.agent.handleWebhookTx(sellTx()); // pre 1000 -> post 500 = they sold 50%
  const p = h.state.data.paper.positions[`dvces:${MINT}`];
  assert.ok(p, "still open after a partial sell");
  assert.equal(BigInt(p.rawHeld), before / 2n, "we sold the same 50%");
  h.setTheirBalances({ preRaw: 1000n, postRaw: 50n, solDeltaLamports: null, feeLamports: 5000 }); // 95% = exit
  await h.agent.handleWebhookTx(sellTx());
  assert.equal(h.state.data.paper.positions[`dvces:${MINT}`], undefined, "fully closed");
  assert.equal(h.state.data.paper.closed.filter((c) => c.partial).length, 2, "two exit events logged");
});

test("their sell with no position of ours is ignored", async () => {
  const h = harness();
  await h.agent.handleWebhookTx(sellTx());
  assert.equal(h.state.data.stats.dvces.sellNoPosition, 1);
});

test("add-on buy of the same token is skipped by default", async () => {
  const h = harness();
  await h.agent.handleWebhookTx(buyTx());
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.state.data.stats.dvces.skipped["add-on"], 1);
});

test("tokens the tracked wallet created are skipped", async () => {
  const h = harness({ rc: { score: 5, creator: W, topRisks: [] } });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.state.data.stats.dvces.skipped["own-token"], 1);
  assert.equal(Object.keys(h.state.data.paper.positions).length, 0);
});

test("high RugCheck score is skipped; no route is skipped; high price impact is skipped", async () => {
  let h = harness({ rc: { score: 80, creator: "x", topRisks: [] } });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.state.data.stats.dvces.skipped["rug-score"], 1);
  h = harness({ noRoute: true });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.state.data.stats.dvces.skipped["no-route"], 1);
  h = harness({ impact: 0.08 }); // 8%
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.state.data.stats.dvces.skipped["price-impact"], 1);
});

test("stale signals (detected late) are skipped", async () => {
  const h = harness();
  const t = buyTx(); t.timestamp = Math.floor(Date.now() / 1000) - 120;
  await h.agent.handleWebhookTx(t);
  assert.equal(h.state.data.stats.dvces.skipped["stale"], 1);
});

test("duplicate webhook delivery is processed once", async () => {
  const h = harness();
  const t = buyTx();
  await h.agent.handleWebhookTx(t);
  await h.agent.handleWebhookTx(t);
  assert.equal(h.state.data.stats.dvces.paperBuys, 1);
});

// ---------------- live gating + risk limits ----------------
test("live: wallet mode 'live' alone does NOT trade unless AGENT_LIVE and TRADING_ENABLED are on", async () => {
  let h = harness({ mode: "live", agentLive: false });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.calls.swaps, 0);
  h = harness({ mode: "live", agentLive: true, tradingEnabled: false });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.calls.swaps, 0);
});

test("live: fully armed executes a buy, records the position, posts to Discord", async () => {
  const h = harness({ mode: "live", agentLive: true });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.calls.swaps, 1);
  assert.ok(h.state.data.live.positions[`dvces:${MINT}`]);
  assert.ok(h.posts.some((p) => p.embeds && /LIVE BUY/.test(p.embeds[0].title)));
});

test("live: unknown RugCheck result fails closed (paper still logs it)", async () => {
  const h = harness({ mode: "live", agentLive: true, rc: { score: null, creator: null, topRisks: [] } });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.calls.swaps, 0);
  assert.equal(h.state.data.stats.dvces.skipped["live-unknown-risk"], 1);
  assert.ok(h.state.data.paper.positions[`dvces:${MINT}`]);
});

test("live: SOL reserve blocks a buy that would drain fee money", async () => {
  const h = harness({ mode: "live", agentLive: true, solBalance: 0.07 });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.calls.swaps, 0);
  assert.equal(h.state.data.stats.dvces.skipped["sol-reserve"], 1);
});

test("live: max open positions and total budget are enforced", async () => {
  const h = harness({ mode: "live", agentLive: true });
  for (const m of ["A", "B", "C"]) {
    h.state.data.live.positions[`x:${m}`] = { key: `x:${m}`, wallet: "x", mint: m, costSol: 0.05, feeSol: 0, rawHeld: "1" };
  }
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.calls.swaps, 0);
  assert.equal(h.state.data.stats.dvces.skipped["max-positions"], 1);
});

test("live: daily loss limit blocks new buys and alerts once", async () => {
  const h = harness({ mode: "live", agentLive: true });
  h.state.data.daily.realizedSol = -0.1;
  await h.agent.handleWebhookTx(buyTx(1.5, MINT));
  await h.agent.handleWebhookTx(buyTx(1.5, MINT2));
  assert.equal(h.calls.swaps, 0);
  assert.equal(h.posts.filter((p) => /Daily loss limit/.test(p.embeds[0].title)).length, 1);
});

test("live: paused blocks new buys but paper keeps logging", async () => {
  const h = harness({ mode: "live", agentLive: true });
  await h.agent.pause();
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.calls.swaps, 0);
  assert.ok(h.state.data.paper.positions[`dvces:${MINT}`]);
});

test("live: failed swap posts an error and records no position", async () => {
  const h = harness({ mode: "live", agentLive: true, swapFails: true });
  await h.agent.handleWebhookTx(buyTx());
  assert.equal(h.state.data.live.positions[`dvces:${MINT}`], undefined);
  assert.ok(h.posts.some((p) => /Live buy failed/.test(p.embeds[0].title)));
});

test("live: mirrored sell exits our position; panic sells everything", async () => {
  const h = harness({ mode: "live", agentLive: true, theirBalances: { preRaw: 1000n, postRaw: 0n, solDeltaLamports: null, feeLamports: 5000 } });
  await h.agent.handleWebhookTx(buyTx());
  assert.ok(h.state.data.live.positions[`dvces:${MINT}`]);
  await h.agent.handleWebhookTx(sellTx());
  assert.equal(h.state.data.live.positions[`dvces:${MINT}`], undefined);
  assert.equal(h.calls.swaps, 2);

  const h2 = harness({ mode: "live", agentLive: true });
  await h2.agent.handleWebhookTx(buyTx());
  const res = await h2.agent.panic();
  assert.equal(res.length, 1);
  assert.equal(h2.state.data.live.positions[`dvces:${MINT}`], undefined);
  assert.equal(h2.state.data.paused, true);
});

// ---------------- config ----------------
test("shipped agent-config.json loads with 4 valid wallets", () => {
  const c = loadAgentConfig(require("path").join(__dirname, "..", "agent-config.json"));
  assert.deepEqual(c.wallets.map((w) => w.label), ["dvces", "Decu", "trunoest", "cupsey"]);
  // Chosen setup: only dvces is live-eligible (and still needs AGENT_LIVE + TRADING_ENABLED); the rest are paper-only.
  assert.deepEqual(c.wallets.map((w) => w.mode), ["live", "paper", "paper", "paper"]);
});


// ---------------- ordering: sells must never be dropped while a buy is still in flight ----------------
// The server fires every webhook event concurrently, and a buy takes seconds (RugCheck, quote, swap).
// A sell that lands in that window used to find "no position" and be thrown away.
test("race: paper sell that arrives while the buy is still processing is not lost", async () => {
  const h = harness({ rugDelayMs: 60, theirBalances: { preRaw: 1000n, postRaw: 0n, solDeltaLamports: null, feeLamports: 5000 } });
  await Promise.allSettled([h.agent.handleWebhookTx(buyTx()), h.agent.handleWebhookTx(sellTx())]);
  assert.equal(Object.keys(h.state.data.paper.positions).length, 0, "position must be closed, not left open");
  assert.ok(h.state.data.paper.closed.length >= 1);
  assert.equal(h.state.data.stats.dvces.sellNoPosition || 0, 0, "sell must not be discarded as 'no position'");
});

test("race: live position is sold when the trader exits mid-buy (no stranded bag)", async () => {
  const h = harness({ mode: "live", agentLive: true, rugDelayMs: 60, theirBalances: { preRaw: 1000n, postRaw: 0n, solDeltaLamports: null, feeLamports: 5000 } });
  await Promise.allSettled([h.agent.handleWebhookTx(buyTx()), h.agent.handleWebhookTx(sellTx())]);
  assert.equal(Object.keys(h.state.data.live.positions).length, 0, "live position must have been exited");
  assert.equal(h.calls.swaps, 2, "one buy swap + one sell swap");
});

// ---------------- tiny sells are batched instead of churning fees ----------------
test("sells: several tiny trims are accumulated, then mirrored once they add up", async () => {
  const h = harness();
  await h.agent.handleWebhookTx(buyTx());
  const key = `dvces:${MINT}`;
  const raw0 = BigInt(h.state.data.paper.positions[key].rawHeld);
  h.setTheirBalances({ preRaw: 1000n, postRaw: 960n, solDeltaLamports: null, feeLamports: 5000 }); // 4% trim
  await h.agent.handleWebhookTx(sellTx());
  assert.equal(h.state.data.paper.positions[key].rawHeld, raw0.toString(), "4% is below the 10% threshold: nothing sold yet");
  assert.equal(h.state.data.stats.dvces.sellDeferred, 1);
  h.setTheirBalances({ preRaw: 960n, postRaw: 860n, solDeltaLamports: null, feeLamports: 5000 }); // ~10.4% more
  await h.agent.handleWebhookTx(sellTx());
  assert.ok(BigInt(h.state.data.paper.positions[key].rawHeld) < raw0, "accumulated trims crossed the threshold: we sold");
});

test("sells: a full exit is mirrored immediately regardless of threshold", async () => {
  const h = harness();
  await h.agent.handleWebhookTx(buyTx());
  h.setTheirBalances({ preRaw: 1000n, postRaw: 0n, solDeltaLamports: null, feeLamports: 5000 });
  await h.agent.handleWebhookTx(sellTx());
  assert.equal(Object.keys(h.state.data.paper.positions).length, 0);
});

// ---------------- admin auth ----------------
test("admin: token in the URL query is rejected; header and POST body are accepted", () => {
  const { makeAdminCheck } = require("../agent/admin");
  const isAdmin = makeAdminCheck("a".repeat(32));
  assert.equal(isAdmin({ headers: {}, query: { token: "a".repeat(32) }, body: {} }), false, "query tokens leak into logs/history");
  assert.equal(isAdmin({ headers: { "x-admin-token": "a".repeat(32) }, query: {}, body: {} }), true);
  assert.equal(isAdmin({ headers: {}, query: {}, body: { token: "a".repeat(32) } }), true);
  assert.equal(isAdmin({ headers: { "x-admin-token": "wrong" }, query: {}, body: {} }), false);
  assert.equal(makeAdminCheck("")({ headers: { "x-admin-token": "" }, query: {}, body: {} }), false, "no token configured = always denied");
});
